# Resume Kipp

A Pen created on CodePen.io. Original URL: [https://codepen.io/jekipp13/pen/XWqWJLE](https://codepen.io/jekipp13/pen/XWqWJLE).

